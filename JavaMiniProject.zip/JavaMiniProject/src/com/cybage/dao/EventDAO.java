package com.cybage.dao;

import java.util.List;

import com.cybage.bean.User;

public interface EventDAO {
//	user
	public boolean registerUser(User registerBean);
	public boolean updateUserProfile(User user);
	public User getUserById(int user_id);
	public List<User> getAlluser();
	public boolean changeUserPassword(User user);
	public String authenticateUser(User user);
}