package com.cybage.service;

import java.util.List;

import com.cybage.bean.User;

public interface EventService {
	public boolean updateUserProfile(User user);
	public User getUserById(int user_id);
	public boolean registerUser(User registerBean);
	public List<User> getAllUser();
	public boolean changeUserPassword(User user);
	public String authenticateUser(User user);

}
