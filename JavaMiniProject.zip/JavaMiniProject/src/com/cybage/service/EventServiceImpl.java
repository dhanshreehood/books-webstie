package com.cybage.service;

import java.util.List;

import com.cybage.bean.User;

import com.cybage.dao.EventDAO;
import com.cybage.dao.EventDaoImpl;

public class EventServiceImpl implements EventService {
	
	private EventDAO eventDao=new EventDaoImpl();

	@Override
	public boolean updateUserProfile(User user) {
			return  eventDao.updateUserProfile(user);	
	}

	@Override
	public User getUserById(int user_id) {
		return eventDao.getUserById(user_id);
	}


	@Override
	public List<User> getAllUser() {
		return eventDao.getAlluser();
	}

	@Override
	public boolean registerUser(User registerBean) {
		return eventDao.registerUser(registerBean);
	}

	@Override
	public boolean changeUserPassword(User user) {
		return eventDao.changeUserPassword(user);
	}

	@Override
	public String authenticateUser(User user) {
		return eventDao.authenticateUser(user);
	}

}