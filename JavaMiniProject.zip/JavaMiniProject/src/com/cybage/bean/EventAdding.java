package com.cybage.bean;

public class EventAdding {
//	event added by organizer
	private int event_id;
	private String event_name;
	private String event_email;
	private String event_address;
	private String event_category;
	private String event_description;
	private String event_image;
	private String event_price;
	private String event_status;
	
//	constructor
	public EventAdding() {
		
	}
	
//	constructor using fields
	public EventAdding(int event_id, String event_name, String event_email, String event_address, String event_category,
			String event_description, String event_image, String event_price, String event_status) {
		super();
		this.event_id = event_id;
		this.event_name = event_name;
		this.event_email = event_email;
		this.event_address = event_address;
		this.event_category = event_category;
		this.event_description = event_description;
		this.event_image = event_image;
		this.event_price = event_price;
		this.event_status = event_status;
	}
	//	getter and setter
	public int getEvent_id() {
		return event_id;
	}
	public void setEvent_id(int event_id) {
		this.event_id = event_id;
	}
	public String getEvent_name() {
		return event_name;
	}
	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}
	public String getEvent_email() {
		return event_email;
	}
	public void setEvent_email(String event_email) {
		this.event_email = event_email;
	}
	public String getEvent_address() {
		return event_address;
	}
	public void setEvent_address(String event_address) {
		this.event_address = event_address;
	}
	public String getEvent_category() {
		return event_category;
	}
	public void setEvent_category(String event_category) {
		this.event_category = event_category;
	}
	public String getEvent_description() {
		return event_description;
	}
	public void setEvent_description(String event_description) {
		this.event_description = event_description;
	}
	public String getEvent_image() {
		return event_image;
	}
	public void setEvent_image(String event_image) {
		this.event_image = event_image;
	}
	public String getEvent_price() {
		return event_price;
	}
	public void setEvent_price(String event_price) {
		this.event_price = event_price;
	}
	public String getEvent_status() {
		return event_status;
	}
	public void setEvent_status(String event_status) {
		this.event_status = event_status;
	}

		
}