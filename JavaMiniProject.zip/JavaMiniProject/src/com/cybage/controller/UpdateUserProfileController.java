package com.cybage.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.User;
import com.cybage.service.EventService;
import com.cybage.service.EventServiceImpl;

/**
 * Servlet implementation class UpdateUserProfileController
 */
@WebServlet("/UpdateUserProfileController")
public class UpdateUserProfileController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EventService eventService = new EventServiceImpl();
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	int user_id=Integer.parseInt(request.getParameter("user_id"));
	User user=eventService.getUserById(user_id);
	
	request.setAttribute("user", user);
	RequestDispatcher dispatcher = request.getRequestDispatcher("updateUserProfile.jsp");
	dispatcher.forward(request, response);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = new User();
		
		//retrieving all parameters from jsp page
		user.setUser_id(Integer.parseInt(request.getParameter("user_id")));
		user.setFirst_name(request.getParameter("first_name"));
		user.setLast_name(request.getParameter("last_name"));
		user.setUsername(request.getParameter("username"));
		user.setPassword(request.getParameter("password"));
		user.setEmail(request.getParameter("email"));
		user.setAddress(request.getParameter("address"));
		user.setContact(request.getParameter("contact"));
	
	boolean flag = eventService.updateUserProfile(user);
	
	if (flag) {
		System.out.println("Record updated successfully");
		/*
		 * RequestDispatcher dispatcher =
		 * request.getRequestDispatcher("EmployeeServlet"); dispatcher.forward(request,
		 * response);
		 */
		response.sendRedirect("EventServlet");
	} else {
		System.out.println("Some error");
	}
}


}
